package com.dragon.download.core

import android.os.Handler
import android.os.Looper
import android.util.Log
import com.dragon.download.listener.DownloadListener
import com.dragon.download.listener.NotificationListener
import com.dragon.download.utils.DownloadProvider

abstract class DownloadAbstractTask(val downloadRequest: DownloadRequest) : Runnable {

    protected var outputPath = ""

    private val handler = Handler(Looper.myLooper()!!)

    //下载监听
    internal val downloadListeners = mutableListOf<DownloadListener>()

    init {
        if (downloadRequest.needNotify) {
            runOnUi {
                registerDownloadListener(NotificationListener(DownloadProvider.context))
            }
        }
    }

    //注册下载监听
    fun registerDownloadListener(downloadListener: DownloadListener) {
        downloadListeners.add(downloadListener)
    }

    internal fun downloadError(throwable: Throwable) {
        runOnUi {
            downloadListeners.forEach {
                it.onDownloadError(key = downloadRequest.url, error = throwable)
            }
        }
    }

    internal fun downloadResume() {
        runOnUi {
            downloadListeners.forEach {
                it.onDownloadResume(key = downloadRequest.url)
            }
        }
    }

    internal fun downloadPrepare() {
        runOnUi {
            downloadListeners.forEach {
                it.onPrepare(key = downloadRequest.url)
            }
        }
    }

    internal fun downloadPause() {
        runOnUi {
            downloadListeners.forEach {
                it.onDownloadPause(key = downloadRequest.url)
            }
        }
    }

    internal fun downloadUpdate(progress: Int, current: Long, total: Long) {
        runOnUi {
            downloadListeners.forEach {
                it.onProgressUpdate(
                    key = downloadRequest.url,
                    progress = progress,
                    read = current,
                    count = total,
                )
            }
        }
    }

    internal fun downloadSuccess() {
        runOnUi {
            downloadListeners.forEach {
                it.onDownloadSuccess(
                    key = downloadRequest.url,
                    saveAddress = outputPath
                )
            }
        }
    }

    internal fun downloadCancel() {
        runOnUi {
            downloadListeners.forEach {
                it.onCancel(key = downloadRequest.url)
            }
        }
    }

    private fun runOnUi(block: () -> Unit) {
        handler.post {
            block.invoke()
        }
    }
}