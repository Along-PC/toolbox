package com.dragon.download.exception

import java.lang.Exception

class CancelException:Exception() {
}