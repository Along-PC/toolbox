package com.dragon.download

import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.OnLifecycleEvent
import com.dragon.download.core.DownloadPool
import com.dragon.download.core.DownloadRequest
import com.dragon.download.core.DownloadTask
import com.dragon.download.listener.DownloadListener

class DownloadManager:LifecycleObserver {

    private val downloadPool= DownloadPool()
    private val downloadChain=HashMap<DownloadRequest,DownloadTask>()

    fun download(downloadRequest: DownloadRequest,lifecycleOwner: LifecycleOwner?=null){
        lifecycleOwner?.let {
            it.lifecycle.addObserver(this)
        }
        val downloadTask=DownloadTask(downloadRequest)
        downloadChain.put(downloadRequest,downloadTask)
        downloadPool.download(downloadTask)
    }

    fun pause(downloadRequest: DownloadRequest){
        downloadChain.get(downloadRequest)?.pause()
    }

    fun resume(downloadRequest: DownloadRequest){
        downloadChain.get(downloadRequest)?.resume()
    }

    fun cancel(downloadRequest: DownloadRequest){
        downloadChain.get(downloadRequest)?.cancel()
    }

    fun registerListener(downloadRequest: DownloadRequest,listener: DownloadListener){
        downloadChain.get(downloadRequest)?.registerDownloadListener(listener)
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_DESTROY)
    private fun onDestory(){
        downloadPool.cancel()
    }

}