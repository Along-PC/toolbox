package com.dragon.download.exception

class ExistException:Exception() {

}