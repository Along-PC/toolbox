package com.dragon.download.listener

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import com.dragon.download.R
import java.util.*

class NotificationListener(val context: Context) : DownloadListener {

    private val notificationManager =
        context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    private var notification: Notification? = null
    private var notificationBuilder: NotificationCompat.Builder? = null
    private val notifyId = Random().nextInt(10000)

    val TAG="NotificationListener"

    override fun onPrepare(key: String) {
        val channelId = "channel_id_$key"
        val channelName = "channel_name_$key"
        notificationBuilder = NotificationCompat
            .Builder(context, channelId)
            .setContentTitle("下载管理")
            .setSmallIcon(getAppIcon())
            .setProgress(100, 0, false)

        notification = notificationBuilder?.build()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationChannel =
                NotificationChannel(channelId, channelName, NotificationManager.IMPORTANCE_DEFAULT)
            notificationManager.createNotificationChannel(notificationChannel)
        }
        notificationManager.notify(notifyId, notification)
    }

    override fun onProgressUpdate(key: String, progress: Int, read: Long, count: Long) {
        notificationBuilder?.setProgress(100, progress, false)
        notificationManager.notify(notifyId, notificationBuilder?.build())
    }

    override fun onDownloadError(key: String, error: Throwable) {
        cancelNotify()
    }

    private fun cancelNotify() {
        notificationManager.cancel(notifyId)
    }

    override fun onDownloadSuccess(key: String, saveAddress: String) {
        notificationBuilder?.setContentTitle("下载完成")
        notificationManager.notify(notifyId, notificationBuilder?.build())
        cancelNotify()
    }

    override fun onDownloadPause(key: String) {
        notificationBuilder?.setContentTitle("下载暂停")
        notificationManager.notify(notifyId, notificationBuilder?.build())
    }

    override fun onDownloadResume(key: String) {
    }

    override fun onCancel(key: String) {
        Log.d(TAG, "onCancel() called with: key = $key")
        cancelNotify()
    }

    fun getAppIcon(): Int {
        val packageManager = context.applicationContext.packageManager
        val packageInfo = packageManager.getPackageInfo(context.packageName, 0)
        return packageInfo.applicationInfo.icon
    }

}